#include <iostream>
using std::cout;
using std::endl;

#include <stdlib.h>

#include "stringStack.h"

void StringStack::push(const string& x) {
}

string StringStack::pop() {
}

string StringStack::topOfStack() {
}

bool StringStack::isEmpty() {
}
